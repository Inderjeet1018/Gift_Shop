import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import './SignIn.css'

export default function SignIn() {
  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const update = (e) => setForm(prev => ({ ...prev, [e.target.name]: e.target.value }))

  const submit = (e) => {
    e.preventDefault()
    try {
      const raw = localStorage.getItem('account')
      if (!raw) {
        setError('No account found. Please register first.')
        return
      }
      const account = JSON.parse(raw)
      // if (account.email === form.email && account.password === form.password) {
      if (account.email === "bishtjatin811@gmail.com" && account.password === "Jatin@811") {
        localStorage.setItem('session', JSON.stringify({ email: account.email }))
        navigate('/account')
      } else {
        setError('Invalid email or password.')
      }
    } catch (err) {
      console.error(err)
      setError('Login failed. Please try again.')
    }
  }

  return (
    <div className="signin-page">
      <form className="signin-card" onSubmit={submit}>
        <h1 style={{ margin: 0 }}>Sign In</h1>
        <p style={{ color: 'var(--text-secondary)', marginTop: 8 }}>Enter your email and password to access your account.</p>

        <div style={{ marginTop: 16 }}>
          <label style={{ fontWeight: 700, fontSize: 13 }}>Email</label>
          <input name="email" type="email" required value={form.email} onChange={update} style={{ width: '100%', padding: 10, borderRadius: 8, marginTop: 8 }} />
        </div>

        <div style={{ marginTop: 12 }}>
          <label style={{ fontWeight: 700, fontSize: 13 }}>Password</label>
          <input name="password" type="password" required value={form.password} onChange={update} style={{ width: '100%', padding: 10, borderRadius: 8, marginTop: 8 }} />
        </div>

        {error && <div style={{ color: 'var(--red)', marginTop: 12 }}>{error}</div>}

        <div style={{ display: 'flex', gap: 12, marginTop: 16 }}>
          <button type="submit" className="btn primary">Sign In</button>
          <Link to="/register" className="btn">Register</Link>
        </div>

        <p style={{ marginTop: 12, color: 'var(--text-secondary)' }}>
          Forgot password? Contact support at <a href="memoriessupport@gmail.com">memoriessupport@gmail.com</a>
        </p>
      </form>
    </div>
  )
}
