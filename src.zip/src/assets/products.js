const products = [
  {
    id: '1',
    title: 'Elegant Pink Gift Box',
    price: 49.99,
    rating: 4.8,
    images: [
      'https://images.unsplash.com/photo-1608895852747-a83d7fec0c2b?w=900&q=80',
      'https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=900&q=80'
    ],
    category: 'Birthday Gifts',
    description: 'Premium curated gift box with ribbons and treats.'
  },
  {
    id: '2',
    title: 'Luxury Chocolates',
    price: 29.99,
    rating: 4.6,
    images: [
      'https://images.unsplash.com/photo-1599599810694-b5ac4dd37e4b?w=900&q=80',
      'https://images.unsplash.com/photo-1599599812694-88af83d3b546?w=900&q=80'
    ],
    category: 'Chocolates',
    description: 'Assorted artisanal chocolates.'
  },
  {
    id: '3',
    title: 'Fresh Flower Bouquet',
    price: 39.99,
    rating: 4.9,
    images: [
      'https://images.unsplash.com/photo-1561181286-d3fee7d55364?w=900&q=80',
      'https://images.unsplash.com/photo-1489824904134-891ab64532f1?w=900&q=80'
    ],
    category: 'Flowers',
    description: 'Hand-tied seasonal flowers.'
  },
  {
    id: '4',
    title: 'Anniversary Gift Hamper',
    price: 59.99,
    rating: 4.7,
    images: [
      'https://images.unsplash.com/photo-1503602642458-232111445657?w=900&q=80',
      'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=900&q=80'
    ],
    category: 'Anniversary Gifts',
    description: 'Luxurious anniversary gift hamper with wine and treats.'
  },
  {
    id: '5',
    title: 'Red Roses Bundle',
    price: 44.99,
    rating: 4.9,
    images: [
      'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=900&q=80',
      'https://images.unsplash.com/photo-1563241527-3004b7be0ffd?w=900&q=80'
    ],
    category: 'Flowers',
    description: 'Beautiful dozen red roses with lush greenery.'
  },
  {
    id: '6',
    title: 'Personalized Gift Basket',
    price: 54.99,
    rating: 4.8,
    images: [
      'https://images.unsplash.com/photo-1599599810962-8a1f2fe85ae2?w=900&q=80',
      'https://images.unsplash.com/photo-1599599811002-b5f6b9c2a6f9?w=900&q=80'
    ],
    category: 'Custom Gifts',
    description: 'Customizable gift basket with your favorite items.'
  },
  {
    id: '7',
    title: 'Premium Chocolate Truffles',
    price: 34.99,
    rating: 4.7,
    images: [
      'https://images.unsplash.com/photo-1599599810990-fd56a4f22f35?w=900&q=80',
      'https://images.unsplash.com/photo-1599599811045-8b7dfd7d1e2f?w=900&q=80'
    ],
    category: 'Chocolates',
    description: 'Handcrafted chocolate truffles with assorted fillings.'
  },
  {
    id: '8',
    title: 'Sunflower Garden Bundle',
    price: 36.99,
    rating: 4.6,
    images: [
      'https://images.unsplash.com/photo-1570046281653-1f71a7fe7a2b?w=900&q=80',
      'https://images.unsplash.com/photo-1500595046891-b7d6d5ecb7b0?w=900&q=80'
    ],
    category: 'Flowers',
    description: 'Bright sunflower arrangement for any occasion.'
  }
]

export default products
